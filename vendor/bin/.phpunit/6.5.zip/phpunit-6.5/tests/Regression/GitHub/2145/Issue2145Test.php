<?php
class Issue2145Test extends PHPUnit\Framework\TestCase
{
    public static function setUpBeforeClass()
    {
        throw new Exception;
    }

    public function testOne()
    {
    }

    public function testTwo()
    {
    }
}
