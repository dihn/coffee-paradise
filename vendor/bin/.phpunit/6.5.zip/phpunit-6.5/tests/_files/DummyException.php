<?php

class DummyException extends Exception
{
}
